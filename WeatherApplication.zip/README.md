# WeatherApplication
 Weather application with node.js and express.js
